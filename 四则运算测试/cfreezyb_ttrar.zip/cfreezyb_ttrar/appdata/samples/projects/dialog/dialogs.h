#define IDD_MAIN                    100
#define IDC_OK                      101
#define IDC_CANCEL                  102
#define IDC_TEXT                    103
